#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <opencv2/opencv.hpp>
using namespace cv;

#include "cameraWorker.h"
#include <QThread>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void alternarLed();
    //void updateFrame();

    void on_pushButton_3_clicked();

private:
    Ui::MainWindow *ui;
    int contador = 0;
    void actualizarEtiqueta();

    // Camera
    //cv::VideoCapture cap;
    //QTimer *timerCamera;
    void startCameraWorker();
    CameraWorker *cameraWorker = nullptr;   // <-- ADD THIS
    QThread *cameraThread = nullptr;        // <-- ADD THIS
};

#endif // MAINWINDOW_H
