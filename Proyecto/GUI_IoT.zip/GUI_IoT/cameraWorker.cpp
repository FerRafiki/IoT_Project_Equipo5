#include "cameraWorker.h"
#include <QDebug>
#include <QCoreApplication>


                   CameraWorker::CameraWorker(QObject *parent) : QObject(parent) {}

void CameraWorker::start() {
    running = true;

    cv::VideoCapture cap(0, cv::CAP_V4L2);    // <-- force correct backend

    if (!cap.isOpened()) {
        qDebug() << "[CameraWorker] Camera could NOT be opened!";
        emit frameReady(QImage());
        return;
    }
    qDebug() << "[CameraWorker] Camera OPENED.";

    // Force MJPEG (fixes 90% of Linux webcams)
    cap.set(cv::CAP_PROP_FOURCC, cv::VideoWriter::fourcc('M','J','P','G'));
    cap.set(cv::CAP_PROP_FRAME_WIDTH, 640);
    cap.set(cv::CAP_PROP_FRAME_HEIGHT, 480);

    cv::Mat frame;

    while (running) {
        cap >> frame;
        if (frame.empty()){
            qDebug() << "[CameraWorker] EMPTY frame received!";
            QThread::msleep(100);
            continue;
        }

        //qDebug() << "[CameraWorker] Got frame:" << frame.cols << "x" << frame.rows;

        cv::cvtColor(frame, frame, cv::COLOR_BGR2RGB);

        QImage img(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);

        emit frameReady(img.copy());

        //QThread::msleep(30);
        //QThread::currentThread()->msleep(30);
        QThread::msleep(30);
        //QCoreApplication::processEvents();


    }

    cap.release();
    qDebug() << "[CameraWorker] Camera STOPPED.";
}

void CameraWorker::stop() {
    running = false;
}
