#include "mainwindow.h"
#include "./ui_mainwindow.h"

#include <QTimer>
#include <QThread>
#include <QDebug>
#include <QProcess>
#include <QFile>

#include "cameraWorker.h"   // <-- ADD THIS

// ─────────────────────────────────────────────
// Helpers para LED
// ─────────────────────────────────────────────
static inline void setLedOn(QLabel* LED) {
    LED->setStyleSheet("background-color: #00d000; border: 1px solid #0a0; border-radius: 10px;");
}

static inline void setLedOff(QLabel* LED) {
    LED->setStyleSheet("background-color: #404040; border: 1px solid #333; border-radius: 10px;");
}

// ─────────────────────────────────────────────
// Constructor
// ─────────────────────────────────────────────
/*MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    qDebug() << "cameraLabel objectName =" << ui->cameraLabel->objectName();


    // ───────── LED SIMULATION ─────────
    setLedOff(ui->LED);

    auto *timerLed = new QTimer(this);
    //connect(timerLed, &QTimer::timeout, this, &MainWindow::alternarLed);
    timerLed->start(1000);

    // ───────── LCD INITIAL VALUE ─────────
    // actualizarEtiqueta();

    // ───────── CAMERA THREAD SETUP ─────────
    worker = new CameraWorker();
    cameraThread = new QThread();

    worker->moveToThread(cameraThread);

    // When the thread starts, run the worker loop
    connect(cameraThread, &QThread::started, worker, &CameraWorker::start);

    // When a frame is ready, display it
    //connect(worker, &CameraWorker::frameReady, this,
    //        [this](const QImage &img){
    //            if (!img.isNull()) {
    //                ui->cameraLabel->setPixmap(QPixmap::fromImage(img));
    //            }
    //        }
    //        );
    connect(worker, &CameraWorker::frameReady, this,
            [this](const QImage &img){
                qDebug() << "Received frame:" << img.width() << "x" << img.height();

                if (ui->cameraLabel == nullptr) {
                    qDebug() << "ERROR: cameraLabel is NULL!";
                    return;
                }

                if (img.isNull()) {
                    qDebug() << "ERROR: image is NULL!";
                    return;
                }

                ui->cameraLabel->setPixmap(QPixmap::fromImage(img).scaled(
                    ui->cameraLabel->size(),
                    Qt::KeepAspectRatio,
                    Qt::SmoothTransformation
                    ));

                qDebug() << "Pixmap applied to cameraLabel.";
            }
    );


    //cameraThread->start();
}*/

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    qDebug() << "cameraLabel objectName =" << ui->cameraLabel->objectName();

    setLedOff(ui->LED);



    auto *timerLed = new QTimer(this);
    timerLed->start(1000);

    // Camera is NOT started here anymore.
}




// ─────────────────────────────────────────────
// Destructor
// ─────────────────────────────────────────────
MainWindow::~MainWindow()
{
    /*worker->stop();        // <--- important
    cameraThread->quit();
    cameraThread->wait();

    delete worker;
    delete cameraThread;
    delete ui;*/

    if (cameraWorker) {
        cameraWorker->stop();
    }

    if (cameraThread) {
        cameraThread->quit();
        cameraThread->wait();
    }

}


// ─────────────────────────────────────────────
// LCD LABEL UPDATE
// ─────────────────────────────────────────────
// void MainWindow::actualizarEtiqueta()
// {
//     ui->lcdNumber->display(contador);
// }

// ─────────────────────────────────────────────
// BUTTONS
// ─────────────────────────────────────────────
/*void MainWindow::on_pushButton_clicked()
{
    QString scriptPath = QCoreApplication::applicationDirPath() + "/doorbell.sh";

    QProcess *process = new QProcess(this);

    connect(process, &QProcess::readyReadStandardOutput, [process]() {
        qDebug() << "[SCRIPT OUTPUT]" << process->readAllStandardOutput();
    });

    connect(process, &QProcess::readyReadStandardError, [process]() {
        qDebug() << "[SCRIPT ERROR]" << process->readAllStandardError();
    });

    //process->start(scriptPath);
    process->start("bash", QStringList() << scriptPath);


    if (!process->waitForStarted()) {
        qDebug() << "Failed to start script!";
    }
    ++contador;
    // // actualizarEtiqueta();
}*/


void MainWindow::startCameraWorker()
{
    cameraWorker = new CameraWorker();
    cameraThread = new QThread();

    cameraWorker->moveToThread(cameraThread);

    // Start worker when the thread starts
    connect(cameraThread, &QThread::started,
            cameraWorker, &CameraWorker::start);

    // Display frames in the label
    connect(cameraWorker, &CameraWorker::frameReady,
            this, [this](const QImage &img)
            {
                if (!img.isNull()) {
                    ui->cameraLabel->setPixmap(
                        QPixmap::fromImage(img).scaled(
                            ui->cameraLabel->size(),
                            Qt::KeepAspectRatio,
                            Qt::SmoothTransformation
                            )
                        );
                }
            });

    // Cleanup when the thread finishes
    connect(cameraThread, &QThread::finished, cameraWorker, &QObject::deleteLater);
    connect(cameraThread, &QThread::finished, cameraThread, &QObject::deleteLater);


    cameraThread->start();
}




void MainWindow::on_pushButton_clicked()
{
    QString doorbellPath = QCoreApplication::applicationDirPath() + "/doorbell.sh";
    QString cameraPath   = QCoreApplication::applicationDirPath() + "/camera.sh";

    QProcess *process1 = new QProcess(this);
    QProcess *process2 = new QProcess(this);

    // Connect output for both
    connect(process1, &QProcess::readyReadStandardOutput, [process1]() {
        qDebug() << "[DOORBELL OUTPUT]" << process1->readAllStandardOutput();
    });
    connect(process1, &QProcess::readyReadStandardError, [process1]() {
        qDebug() << "[DOORBELL ERROR]" << process1->readAllStandardError();
    });

    connect(process2, &QProcess::readyReadStandardOutput, [process2]() {
        qDebug() << "[CAMERA OUTPUT]" << process2->readAllStandardOutput();
    });
    connect(process2, &QProcess::readyReadStandardError, [process2]() {
        qDebug() << "[CAMERA ERROR]" << process2->readAllStandardError();
    });

    // When script #1 finishes, run script #2
    connect(process1, &QProcess::finished, [process2, cameraPath]() {
        process2->start("bash", QStringList() << cameraPath);
    });

    // Start script #1
    process1->start("bash", QStringList() << doorbellPath);

    startCameraWorker();

    ++contador;
}


void MainWindow::on_pushButton_2_clicked()
{
    QProcess::execute("pkill -9 gst-launch-1.0");
    QProcess::execute("pkill -f camera.sh");

    --contador;
    // // actualizarEtiqueta();
}

// ─────────────────────────────────────────────
// LED SIMULATION
// ─────────────────────────────────────────────
void MainWindow::alternarLed()
{
    static bool state = false;
    state = !state;
    if (state) setLedOn(ui->LED);
    else       setLedOff(ui->LED);
}




/*
void MainWindow::on_pushButton_3_clicked()
{
    static bool state = false;
    state = !state;
    if (state)
    {
        setLedOn(ui->LED);

        QString scriptPath = QCoreApplication::applicationDirPath() + "/led_on.sh";

        QProcess *process = new QProcess(this);

        connect(process, &QProcess::readyReadStandardOutput, [process]() {
            qDebug() << "[SCRIPT OUTPUT]" << process->readAllStandardOutput();
        });

        connect(process, &QProcess::readyReadStandardError, [process]() {
            qDebug() << "[SCRIPT ERROR]" << process->readAllStandardError();
        });

        //process->start(scriptPath);
        process->start("bash", QStringList() << scriptPath);

        if (!process->waitForStarted()) {
            qDebug() << "Failed to start script!";
        }
    }

    else
    {
         setLedOff(ui->LED);

        QString scriptPath = QCoreApplication::applicationDirPath() + "/led_off.sh";

        QProcess *process = new QProcess(this);

        connect(process, &QProcess::readyReadStandardOutput, [process]() {
            qDebug() << "[SCRIPT OUTPUT]" << process->readAllStandardOutput();
        });

        connect(process, &QProcess::readyReadStandardError, [process]() {
            qDebug() << "[SCRIPT ERROR]" << process->readAllStandardError();
        });

        //process->start(scriptPath);
        process->start("bash", QStringList() << scriptPath);


        if (!process->waitForStarted()) {
            qDebug() << "Failed to start script!";
        }
    }

}*/

void MainWindow::on_pushButton_3_clicked()
{
    // === 1) Leer estado real desde el archivo (si existe) ===
    QString stateFile = "/tmp/led0_state";
    bool realState = false;

    QFile f(stateFile);
    if (f.exists() && f.open(QIODevice::ReadOnly)) {
        QString s = f.readAll().trimmed();
        realState = (s == "1");
        f.close();
    }

    // === 2) Logica original: toggle interno ===
    static bool state = false;
    state = !state;

    // *** OPCIONAL PERO RECOMENDADO ***
    // Sincronizar si necesitas: comentar si no lo quieres
     state = !realState;

    // === 3) Encender ===
    if (state)
    {
        setLedOn(ui->LED);

        QString scriptPath = QCoreApplication::applicationDirPath() + "/led_on.sh";
        QProcess *process = new QProcess(this);

        connect(process, &QProcess::readyReadStandardOutput, [process]() {
            qDebug() << "[SCRIPT OUTPUT]" << process->readAllStandardOutput();
        });

        connect(process, &QProcess::readyReadStandardError, [process]() {
            qDebug() << "[SCRIPT ERROR]" << process->readAllStandardError();
        });

        process->start("bash", QStringList() << scriptPath);

        if (!process->waitForStarted()) {
            qDebug() << "Failed to start script!";
        }
    }

    // === 4) Apagar ===
    else
    {
        setLedOff(ui->LED);

        QString scriptPath = QCoreApplication::applicationDirPath() + "/led_off.sh";
        QProcess *process = new QProcess(this);

        connect(process, &QProcess::readyReadStandardOutput, [process]() {
            qDebug() << "[SCRIPT OUTPUT]" << process->readAllStandardOutput();
        });

        connect(process, &QProcess::readyReadStandardError, [process]() {
            qDebug() << "[SCRIPT ERROR]" << process->readAllStandardError();
        });

        process->start("bash", QStringList() << scriptPath);

        if (!process->waitForStarted()) {
            qDebug() << "Failed to start script!";
        }
    }
}





