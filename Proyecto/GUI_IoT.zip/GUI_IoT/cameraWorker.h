#pragma once
#include <QObject>
#include <QImage>
#include <opencv2/opencv.hpp>
#include <QThread>

class CameraWorker : public QObject {
    Q_OBJECT

public:
    explicit CameraWorker(QObject *parent = nullptr);

public slots:
    void start();
    void stop();     // <-- ADD THIS

signals:
    void frameReady(const QImage &img);

private:
    bool running = true;   // <-- control loop
};


